package bot_core

func NewJoinFox(client *oop.Account, to string) {
	go func() {
		JoinKickFox(client, to)
	}()
	go func() {
		JoinCancelFox(client, to)
	}()
	GetSquad(client, to)
}

func RunBot(client *oop.Account, ch chan int) {
	defer panicHandle("RunBot")
	runtime.GOMAXPROCS(cpu)
	client.Revision = -1
	for {
		multiFunc, err := client.Newsync(100)
		if err != nil || len(multiFunc) == 0 {
			continue
		}
		go func(fetch []*SyncService.Operation) {
			for _, op := range multiFunc {
			    fmt.Println(multiFunc)
			    fmt.Println(op)
				if op.Type == 124 {
					Optime := op.CreatedTime
					rngcmd := GetComs(4, "invitebot")
					Group, user := op.Param1, op.Param2
					invited := strings.Split(op.Param3, "\x1e")
					Room := oop.GetRoom(Group)
					if InArray2(invited, client.MID) {
						if oop.IoGOBot(Group, client) {
							if InArray2(client.Squads, user) {
								go AcckickV2(client, Group)
								if client.Limited == false {
									if !InArrayInt64(cekGo, Optime) {
										cekGo = append(cekGo, Optime)
										AcceptJoin(client, Group)
									}
								}
							} else if UserBot.GetBot(user) {
								go AcckickV2(client, Group)
								if client.Limited == false {
									if !InArrayInt64(cekGo, Optime) {
										cekGo = append(cekGo, Optime)
										AcceptJoin(client, Group)
									}
								}
							} else if GetCodeprem(rngcmd, user, Group) {
								client.AcceptGroupInvitationNormal(Group)
								if client.Limited == false {
									if !InArrayInt64(cekGo, Optime) {
										cekGo = append(cekGo, Optime)
										AcceptJoin(client, Group)
									}
								}
							} else {
								grs, _ := client.GetGroupIdsJoined()
								if InArray2(grs, Group) {
									client.LeaveGroup(Group)
									fl, _ := client.GetAllContactIds()
									if InArray2(fl, user) {
										client.UnFriend(user)
									}
								}
							}
						}
					} else {
						Optime := op.CreatedTime
						if Room.ProInvite {
							if MemUser(Group, user) {
								go func() {
									if filterWar.ceki(user) {
										Banned.AddBan(user)
										kickPelaku(client, Group, user)
										filterWar.deli(user)
									}
								}()
								if filterWar.ceko(Optime) {
									Room.ListInvited = invited
									BanAll(invited)
									go newcancel(client, invited, Group)
								}
							} else {
								if filterWar.ceko(Optime) {
									go cancelallcek(client, invited, Group)
								}
							}
						} else {
							if MemBan(Group, user) {
								go func() {
									if filterWar.ceki(user) {
										kickPelaku(client, Group, user)
										filterWar.deli(user)
									}
								}()
								if filterWar.ceko(Optime) {
									go newcancel(client, invited, Group)
									BanAll(invited)
									go func() {
										CancelV13(client, Group, invited)
									}()
								}
							} else {
								if MemUser(Group, user) {
									go func() {
										if filterWar.ceki(user) {
											for _, vo := range invited {
												if MemBan(Group, vo) {
													Banned.AddBan(user)
													kickPelaku(client, Group, user)
													break
												}
											}
											filterWar.deli(user)
										}
									}()
									if filterWar.ceko(Optime) {
										go cancelallcek(client, invited, Group)
									}
								}
							}
						}
					}
					if _, ok := filtermsg.Get(Optime); !ok {
						filtermsg.Set(Optime, client)
						LogOp(op, client)
						LogGet(op)
					}
				}else if op.Type == 133 {
					runtime.GOMAXPROCS(cpu)
					Optime := op.CreatedTime
					Group, user, Invited := op.Param1, op.Param2, op.Param3
					Room := oop.GetRoom(Group)
					if client.MID == Invited {
						oop.Gones(Group, client)
						if MemUser(Group, user) {
							Banned.AddBan(user)
						}
					} else if !InArray2(Room.GoMid, client.MID) {
						if InArray2(client.Squads, Invited) {
							if MemUser(Group, user) {
								if oop.IoGOBot(Group, client) {
									if filterWar.ceki(user) {
										Banned.AddBan(user)
										kickPelaku(client, Group, user)
										filterWar.deli(user)
									}
									if filterWar.ceki(Invited) {
										groupBackupInv(client, Group, Optime, Invited)
										filterWar.deli(Invited)
									}
								}
							}
						} else {
							if !MemUserN(Group, Invited) {
								if Checkkickuser(Group, user, Invited) {
									back(Group, Invited)
									if filterWar.ceki(user) {
										kickPelaku(client, Group, user)
										filterWar.deli(user)
										if MemUser(Group, user) {
											Banned.AddBan(user)
										}
									}
								}
							} else {
								if Room.ProKick {
									if MemUser(Group, user) {
										if Room.Backup {
											back(Group, Invited)
										}
										if _, ok := Nkick.Get(user); !ok {
											Nkick.Set(user, 1)
											kickPelaku(client, Group, user)
											Banned.AddBan(user)
										}
									}
								}
							}
						}
					} else {
						if InArray2(client.Squads, Invited) {
							if MemUser(Group, user) {
								back(Group, Invited)
								Banned.AddBan(user)
								_, memlist := client.GetGroupMember(Group)
								oke := []string{}
								for mid, _ := range memlist {
									if InArray2(Squadlist, mid) {
										oke = append(oke, mid)
									}
								}
								if len(oke) == 0 {
									if !InArrayInt64(cekGo, Optime) {
										cekGo = append(cekGo, Optime)
										cls := []*oop.Account{}
										Bot2 := Room.Bot
										bots := Room.HaveClient
										go Room.GoClient[0].AcceptGroupInvitationNormal(Group)
										NewJoinFox(Room.GoClient[0], Group)
										Room.GoClient[0].InviteIntoChatPollVer(Group, Bot2)
										Room.GoClient[0].LeaveGroup(Group)
										cls = append(cls, Room.GoClient[0])
										cc := len(cls)
										if cc != 0 {
											if Autojoin == "qr" {
												qrGo(cls[0], bots, Group)
											} else if Autojoin == "invite" {
												cls[0].InviteIntoChatPollVer(Group, Bot2)
											}
											for _, cl := range cls {
												Room.ConvertGo(cl)
											}
										}
									}
								}
							}
						}
					}
					if _, ok := filtermsg.Get(Optime); !ok {
						filtermsg.Set(Optime, client)
						LogOp(op, client)
						LogGet(op)
					}
				}else if op.Type == 130 {
					runtime.GOMAXPROCS(cpu)
					Group, user := op.Param1, op.Param2
					Room := oop.GetRoom(Group)
					if oop.IoGOBot(Group, client) {
						if Room.ProJoin {
							if MemUser(Group, user) {
								if filterWar.ceki(user) {
									kickPelaku(client, Group, user)
									filterWar.deli(user)
									Banned.AddBan(user)
								}
							}
						} else {
							if MemBan(Group, user) {
								if MemUser(Group, user) {
									if filterWar.ceki(user) {
										kickPelaku(client, Group, user)
										filterWar.deli(user)
										Banned.AddBan(user)
									}
								}
							} else {
								if InArray2(Room.ListInvited, user) {
									if MemUser(Group, user) {
										if cekjoin(user) {
											kickPelaku(client, Group, user)
											deljoin(user)
											Room.ListInvited = Remove(Room.ListInvited, user)
										}
									} else {
										Room.ListInvited = Remove(Room.ListInvited, user)
									}
								} else {
									if Room.Welcome {
										if _, ok := cewel.Get(user); !ok {
											cewel.Set(user, 1)
											if cekjoin(user) {
												if !InArray2(Squadlist, user) {
													Room.WelsomeSet(client, Group, user)
												}
											}
										}
									}
								}
							}
						}
					}
					Optime := op.CreatedTime
					if _, ok := filtermsg.Get(Optime); !ok {
						filtermsg.Set(Optime, client)
						LogOp(op, client)
						LogGet(op)
					}
				}
				if op.Type == 122 {
					runtime.GOMAXPROCS(cpu)
					Group, user, invited := op.Param1, op.Param2, op.Param3
					Optime := op.CreatedTime
					Room := oop.GetRoom(Group)
					if client.Limited == false && oop.IoGOBot(Group, client) {
						if MemUser(Group, user) {
							if Room.ProQr || AutoproN == true {
								if invited == "4" {
									if cekOp2(Optime) {
										go func() {
											cans := oop.Actor(Group)
											for _, cl := range cans {
												err := cl.UpdateChatQrV2(Group, true)
												if err == nil {
													break
												}
											}
										}()
										if filterWar.ceki(user) {
											kickPelaku(client, Group, user)
											filterWar.deli(user)
											Banned.AddBan(user)
										}
									}
								}
							} else if LockMode == true {
								if invited == "4" {
									if cekOp2(Optime) {
										if filterWar.ceki(user) {
											Banned.AddLock(user)
										}
									}
								}
							} else if Room.ProPicture || AutoproN == true {
								if invited == "2" {
									if cekOp2(Optime) {
										if filterWar.ceki(user) {
											kickPelaku(client, Group, user)
											filterWar.deli(user)
										}
									}
								}
							} else if Room.ProName || AutoproN == true {
								if invited == "1" {
									if cekOp2(Optime) {
										go func() {
											cans := oop.Actor(Group)
											for _, cl := range cans {
												err := cl.UpdateChatName(Group, Room.Name)
												if err == nil {
													break
												}
											}
										}()
										if filterWar.ceki(user) {
											kickPelaku(client, Group, user)
											filterWar.deli(user)
										}
									}
								}
							} else {
								if MemBan(Group, user) {
									if invited == "4" {
										if cekOp2(Optime) {
											go func() {
												cans := oop.Actor(Group)
												for _, cl := range cans {
													err := cl.UpdateChatQrV2(Group, true)
													if err == nil {
														break
													}
												}
											}()
											if filterWar.ceki(user) {
												kickPelaku(client, Group, user)
												filterWar.deli(user)
												Banned.AddBan(user)
											}
										}
									} else if invited == "1" {
										if cekOp2(Optime) {
											go func() {
												cans := oop.Actor(Group)
												for _, cl := range cans {
													err := cl.UpdateChatName(Group, Room.Name)
													if err == nil {
														break
													}
												}
											}()
											if filterWar.ceki(user) {
												kickPelaku(client, Group, user)
												filterWar.deli(user)
											}
										}
									}
								}
							}
						} 
					}
				        if _, ok := filtermsg.Get(Optime); !ok {
					        filtermsg.Set(Optime, client)
					        LogOp(op, client)
					        LogGet(op)
					    }
					} else if op.Type == 30 {
					Group := op.Param1
					Room := oop.GetRoom(Group)
					if Room.Announce && oop.IoGOBot(Group, client) {
						Optime := op.CreatedTime
						if cekOp(Optime) {
							Room.CheckAnnounce(client, Group)
						}
					}
				} else if op.Type == 123 {
					client.CInvite()
				} else if op.Type == 132 {
					client.CountKick()
				} else if op.Type == 125 {
					client.CCancel()
				} else if op.Type == 126 {
					runtime.GOMAXPROCS(cpu)
					Optime := op.CreatedTime
					Group, user, Invited := op.Param1, op.Param2, op.Param3
					Room := oop.GetRoom(Group)
					if client.MID == Invited {
						oop.Gones(Group, client)
						if MemUser(Group, user) {
							Banned.AddBan(user)
						}
					} else if !InArray2(Room.GoMid, client.MID) {
						if InArray2(client.Squads, Invited) {
							if MemUser(Group, user) {
								if oop.IoGOBot(Group, client) {
									Banned.AddBan(user)
									go func() {
										if filterWar.cek(user) {
											groupBackupKick(client, Group, user, true)
											filterWar.del(user)
										}
									}()
									if filterWar.cek(Invited) {
										groupBackupInv(client, Group, Optime, Invited)
										filterWar.del(Invited)
									}
								}
							}
						} else {
							if !MemUserN(Group, Invited) {
								if Checkkickuser(Group, user, Invited) {
									back(Group, Invited)
									if filterWar.ceki(user) {
										kickPelaku(client, Group, user)
										filterWar.deli(user)
										if MemUser(Group, user) {
											Banned.AddBan(user)
										}
									}
								}
							} else {
								if Room.ProCancel {
									if MemUser(Group, user) {
										if Room.Backup {
											back(Group, Invited)
										}
										if _, ok := Nkick.Get(user); !ok {
											Nkick.Set(user, 1)
											kickPelaku(client, Group, user)
											Banned.AddBan(user)
										}
									}
								}
							}
						}
					} else {
						if MemUser(Group, Invited) {
							if MemUser(Group, user) {
								back(Group, Invited)
								Banned.AddBan(user)
								_, memlist := client.GetGroupMember(Group)
								oke := []string{}
								for mid, _ := range memlist {
									if InArray2(Squadlist, mid) {
										oke = append(oke, mid)
									}
								}
								if len(oke) == 0 {
									if !InArrayInt64(cekGo, Optime) {
										cekGo = append(cekGo, Optime)
										cls := []*oop.Account{}
										Bot := Room.Bot
										bots := Room.HaveClient
										for n, cl := range Room.GoClient {
											if n < 2 {
												go cl.AcceptGroupInvitationNormal(Group)
												cls = append(cls, cl)
											}
										}
										cc := len(cls)
										if cc != 0 {
											Purgesip(Group, cls[0])
											if Autojoin == "qr" {
												qrGo(cls[0], bots, Group)
											} else if Autojoin == "invite" {
												cls[0].InviteIntoChatPollVer(Group, Bot)
											}
											for _, cl := range cls {
												Room.ConvertGo(cl)
											}
										}
									}
								}
							}
						}
					}
					if _, ok := filtermsg.Get(Optime); !ok {
						filtermsg.Set(Optime, client)
						LogOp(op, client)
						LogGet(op)
					}
				} else if op.Type == 5 {
					Group := op.Param1
					if LogMode && !InArray2(client.Squads, Group) {
						logAccess(client, client.Namebot, Group, "addfrind", []string{}, 2)
					}
				} else if op.Type == 55 {
					Optime := op.CreatedTime
					Group, user := op.Param1, op.Param2
					if client.Limited == false && oop.IoGOBot(Group, client) {
						if cekOp(Optime) {
							if MemBan(Group, user) {
								kickPelaku(client, Group, user)
							} else {
								Room := oop.GetRoom(Group)
								if Room.Lurk && !InArray2(checkHaid, user) {
									Room.CheckLurk(client, Group, user)
								}
							}
						}
					}
				} else if op.Type == 26 {
					msg := op.Message
					fmt.Println("op",  op)
					Optime := op.CreatedTime
					if _, ok := Command.Get(Optime); !ok {
						Command.Set(Optime, client)
						if _, ok := filterop.Get(Optime); !ok {
							filterop.Set(Optime, 1)
							Bot(op, client, ch)
						}
					}
					if _, ok := filtermsg.Get(Optime); !ok {
						filtermsg.Set(Optime, client)
						DetectProCancel(msg, client)
						LogOp(op, client)
						LogGet(op)
					}
				}else if op.Type == 30 {
			        Group := op.Param1
			        Room := oop.GetRoom(Group)
			        if Room.Announce && oop.IoGOBot(Group, client) {
				        Optime := op.CreatedTime
				        if cekOp(Optime) {
					        Room.CheckAnnounce(client, Group)
				        }
			        }
				} else if op.Type == 128 {
					Optime := op.CreatedTime
					Group, user := op.Param1, op.Param2
					if !InArray2(Squadlist, user) {
						Room := oop.GetRoom(Group)
						if !InArray2(Room.GoMid, user) {
							client.InviteIntoChatPollVer(Group, Room.GoMid)
						}
						if Room.Backleave {
							jangan := true
							tm, ok := botleave.Get(user)
							if ok {
								if time.Now().Sub(tm.(time.Time)) < 5*time.Second {
									jangan = false
								}
							}
							if jangan {
								if filterWar.ceki(user) {
									if !MemBan(Group, user) && !InArray2(Squadlist, user) && !UserBot.GetBot(user) && !InArray2(Room.GoMid, user) {
										hstg(Group, user)
										Room.Leave = time.Now()
									}
								}
							}
						} else {
							if Room.Leavebool {
								if _, ok := cleave.Get(user); !ok {
									cleave.Set(user, 1)
									if !MemBan(Group, user) && !InArray2(Squadlist, user) && !UserBot.GetBot(user) && !InArray2(Room.GoMid, user) {
										Room.LeaveSet(client, Group, user)
									}
								}
							}
						}
					}
					if _, ok := filtermsg.Get(Optime); !ok {
						filtermsg.Set(Optime, client)
						LogOp(op, client)
						LogGet(op)
					}
				}
			}
		}(multiFunc)
		for _, ops := range multiFunc {
			client.SetSyncRevision(ops.Revision)
		}
	}
}

func getKey(cmd string) string {
	mp := oop.HashToMap(CmdHelper)
	for k, v := range mp {
		if v.(string) == cmd {
			return k
		}
	}
	return cmd
}

func SaveBackup() {
	fmt.Println("start Save Data *__*")
	Data.GbanBack = map[string][]string{}
	Data.GownerBack = map[string][]string{}
	Data.GadminBack = map[string][]string{}
	Data.BanBack = []string{}
	Data.LockBack = []string{}
	Data.SnameBack = MsSname
	Data.RnameBack = MsRname
	Data.ResponBack = MsgRespon
	Data.FuckBack = []string{}
	Data.MuteBack = []string{}
	Data.AnnunceBack = []string{}
	Data.ProQrBack = []string{}
	Data.ProNameBack = []string{}
	Data.ProPictureBack = []string{}
	Data.ProNoteBack = []string{}
	Data.ProAlbumBack = []string{}
	Data.ProjoinBack = []string{}
	Data.ProInviteBack = []string{}
	Data.ProCancelBack = []string{}
	Data.ProkickBack = []string{}
	Data.CreatorBack = []string{}
	Data.SellerBack = []string{}
	Data.BuyerBack = []string{}
	Data.OwnerBack = []string{}
	Data.MasterBack = []string{}
	Data.AdminBack = []string{}
	Data.BotBack = []string{}
	Data.TimeBanBack = map[string]time.Time{}
	if len(oop.KickBans) != 0 {
		for _, cl := range oop.KickBans {
			if _, ok := oop.GetBlock.Get(cl.MID); ok {
				Data.TimeBanBack[cl.MID] = cl.TimeBan
			}
		}
	}
	for _, room := range oop.SquadRoom {
		Data.GbanBack[room.Id] = []string{}
		Data.GownerBack[room.Id] = []string{}
		Data.GadminBack[room.Id] = []string{}
		if room.ProKick {
			Data.ProkickBack = append(Data.ProkickBack, room.Id)
		}
		if room.ProCancel {
			Data.ProCancelBack = append(Data.ProCancelBack, room.Id)
		}
		if room.ProInvite {
			Data.ProInviteBack = append(Data.ProInviteBack, room.Id)
		}
		if room.ProQr {
			Data.ProQrBack = append(Data.ProQrBack, room.Id)
		}
		if room.ProName {
			Data.ProNameBack = append(Data.ProNameBack, room.Id)
		}
		if room.ProPicture {
			Data.ProPictureBack = append(Data.ProPictureBack, room.Id)
		}
		if room.ProNote {
			Data.ProNoteBack = append(Data.ProNoteBack, room.Id)
		}
		if room.ProAlbum {
			Data.ProAlbumBack = append(Data.ProAlbumBack, room.Id)
		}
		if room.ProJoin {
			Data.ProjoinBack = append(Data.ProjoinBack, room.Id)
		}
		if room.Announce {
			Data.AnnunceBack = append(Data.AnnunceBack, room.Id)
		}
	}
	if len(UserBot.Creator) != 0 {
		for _, i := range UserBot.Creator {
			if !InArray2(Data.CreatorBack, i) {
				Data.CreatorBack = append(Data.CreatorBack, i)
			}
		}
	}
	if len(UserBot.Seller) != 0 {
		for _, i := range UserBot.Seller {
			if !InArray2(Data.SellerBack, i) {
				Data.SellerBack = append(Data.SellerBack, i)
			}
		}
	}
	if len(UserBot.Buyer) != 0 {
		for _, i := range UserBot.Buyer {
			if !InArray2(Data.BuyerBack, i) {
				Data.BuyerBack = append(Data.BuyerBack, i)
			}
		}
	}
	if len(UserBot.Owner) != 0 {
		for _, i := range UserBot.Owner {
			if !InArray2(Data.OwnerBack, i) {
				Data.OwnerBack = append(Data.OwnerBack, i)
			}
		}
	}
	if len(UserBot.Master) != 0 {
		for _, i := range UserBot.Master {
			if !InArray2(Data.MasterBack, i) {
				Data.MasterBack = append(Data.MasterBack, i)
			}
		}
	}
	if len(UserBot.Admin) != 0 {
		for _, i := range UserBot.Admin {
			if !InArray2(Data.AdminBack, i) {
				Data.AdminBack = append(Data.AdminBack, i)
			}
		}
	}
	if len(UserBot.Bot) != 0 {
		for _, i := range UserBot.Bot {
			if !InArray2(Data.BotBack, i) {
				Data.BotBack = append(Data.BotBack, i)
			}
		}
	}
	if len(Data.GbanBack) != 0 {
		for to := range Data.GbanBack {
			Room := oop.GetRoom(to)
			if len(Room.Gban) != 0 {
				for _, i := range Room.Gban {
					if MemUser(to, i) {
						if !InArray2(Data.GbanBack[to], i) {
							Data.GbanBack[to] = append(Data.GbanBack[to], i)
						}
					}
				}
			}
		}
	}
	if len(Data.GownerBack) != 0 {
		for to := range Data.GownerBack {
			Room := oop.GetRoom(to)
			if len(Room.Gowner) != 0 {
				for _, i := range Room.Gowner {
					if !InArray2(Data.GownerBack[to], i) {
						Data.GownerBack[to] = append(Data.GownerBack[to], i)
					}
				}
			}
		}
	}
	if len(Data.GadminBack) != 0 {
		for to := range Data.GadminBack {
			Room := oop.GetRoom(to)
			if len(Room.Gadmin) != 0 {
				for _, i := range Room.Gadmin {
					if !InArray2(Data.GadminBack[to], i) {
						Data.GadminBack[to] = append(Data.GadminBack[to], i)
					}
				}
			}
		}
	}
	if len(Banned.Banlist) != 0 {
		for _, i := range Banned.Banlist {
			if MemAccsess(i) {
				if !InArray2(Data.BanBack, i) {
					Data.BanBack = append(Data.BanBack, i)
				}
			}
		}
	}
	if len(Banned.Locklist) != 0 {
		for _, i := range Banned.Locklist {
			if MemAccsess(i) {
				if !InArray2(Data.LockBack, i) {
					Data.LockBack = append(Data.LockBack, i)
				}
			}
		}
	}
	if len(Banned.Fucklist) != 0 {
		for _, i := range Banned.Fucklist {
			if MemAccsess(i) {
				if !InArray2(Data.FuckBack, i) {
					Data.FuckBack = append(Data.FuckBack, i)
				}
			}
		}
	}
	if len(Banned.Mutelist) != 0 {
		for _, i := range Banned.Mutelist {
			if MemAccsess(i) {
				if !InArray2(Data.MuteBack, i) {
					Data.MuteBack = append(Data.MuteBack, i)
				}
			}
		}
	}
	fmt.Println("done save Data *__*")
	SaveData()
}
