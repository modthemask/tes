package bot_contact

func getBot(client *oop.Account, to string) []*oop.Account {
	_, memlist := client.GetGroupMember(to)
	exe := []*oop.Account{}
	for mid, _ := range memlist {
		if InArray2(Squadlist, mid) {
			cl := GetKorban(mid)
			if cl.Limited == false {
				exe = append(exe, cl)
			}
		}
	}
	sort.Slice(exe, func(i, j int) bool {
		return exe[i].KickPoint < exe[j].KickPoint
	})
	oop.GetRoom(to).HaveClient = exe
	return exe
}

func AddContact2(cl *oop.Account, con string) int {
	fl, _ := cl.GetAllContactIds()
	if !InArray2(fl, con) {
		if con != cl.MID && !cl.Limitadd {
			cl.FindAndAddContactsByMid(con)
			return 1
		} else {
			return 0
		}
	}
	return 1
}

func kickDirt(client *oop.Account, to, pelaku string) {
	runtime.GOMAXPROCS(cpu)
	cans := oop.Actor(to)
	for _, cl := range cans {
		if oop.GetRoom(to).Act(cl) {
			in := cl.DeleteOtherFromChat(to, pelaku)
			if in == 35 || in == 10 {
				continue
			} else {
				break
			}
		}
	}
}

func CekPurge(optime int64) bool {
	defer oop.PanicOnly()
	for _, tar := range PurgeOP {
		if tar == optime {
			return false
		}
	}
	PurgeOP = append(PurgeOP, optime)
	return true
}

func cekjoin(optime string) bool {
	defer oop.PanicOnly()
	for _, tar := range opjoin {
		if tar == optime {
			return false
		}
	}
	opjoin = append(opjoin, optime)
	return true
}

func cekOp2(optime int64) bool {
	for _, tar := range cekoptime {
		if tar == optime {
			return false
		}
	}
	cekoptime = append(cekoptime, optime)
	return true
}

// here func getKey

func LogFight(room *oop.LineRoom) {
	defer panicHandle("logfight")
	if LogMode {
		var tx = ""
		for i := 0; i < len(ClientBot); i++ {
			exe := ClientBot[i]
			if !exe.Frez {
				g, err := exe.GetGroupMember(room.Id)
				if err != nil {
					continue
				} else {
					room.Name = g
					break
				}
			}
		}

		tx += fmt.Sprintf("Squad action's in Group:\n%s\n", room.Name)
		if room.Kick != 0 {
			tx += fmt.Sprintf("\nKick's: %v", room.Kick)
		}
		if room.Invite != 0 {
			tx += fmt.Sprintf("\nInvite's: %v", room.Invite)
		}
		if room.Cancel != 0 {
			tx += fmt.Sprintf("\nCancel's: %v", room.Cancel)
		}
		if room.Kick == 0 && room.Invite == 0 && room.Cancel == 0 {
			room.Kick = 0
			room.Invite = 0
			room.Cancel = 0
			return
		}
		room := oop.GetRoom(LogGroup)
		if len(room.Client) != 0 {
			exe, err := SelectBot(room.Client[0], LogGroup)
			if err == nil {
				if exe != nil {
					exe.SendMessage(LogGroup, tx)
				}
			} else {
				LogMode = false
				LogGroup = ""
			}
		}
	}
	room.Kick = 0
	room.Invite = 0
	room.Cancel = 0
}

